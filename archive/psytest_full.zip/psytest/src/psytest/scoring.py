import pandas as pd

def reverse_code(series: pd.Series, max_val: int = 5):
    return max_val + 1 - series

def score_paei(df_items: pd.DataFrame, df_resp: pd.DataFrame) -> pd.DataFrame:
    # df_resp: columns [item_id, answer]
    df = df_resp.merge(df_items[['item_id','scale','reverse']], on='item_id', how='left')
    df['adj'] = df.apply(lambda r: (6 - r['answer']) if r['reverse']==1 else r['answer'], axis=1)
    return df.groupby('scale')['adj'].sum().reset_index(name='raw')
