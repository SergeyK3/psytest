import streamlit as st
import pandas as pd
from pathlib import Path
from .bank import load_items
from .scoring import score_paei

st.title('Психологическое тестирование (MVP)')
base = Path(__file__).resolve().parents[2] / 'data' / 'bank'
items = load_items(base/'paei_items.csv')
st.subheader('PAEI')
answers = {}
for _, row in items.iterrows():
    answers[row['item_id']] = st.slider(row['text'], 1, 5, 3)
if st.button('Рассчитать'):
    df_resp = pd.DataFrame({'item_id': list(answers.keys()), 'answer': list(answers.values())})
    scores = score_paei(items, df_resp)
    st.write(scores)
