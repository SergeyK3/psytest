
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm

def render_pdf(scores: dict, chart_path: Path, out_path: Path):
    c = canvas.Canvas(str(out_path), pagesize=A4)
    width, height = A4

    c.setFont("Times-Roman", 16)
    c.drawString(2*cm, height - 2*cm, "Отчёт по психологическому тестированию")

    c.setFont("Times-Roman", 12)
    y = height - 3*cm
    for k, v in scores.items():
        c.drawString(2*cm, y, f"{k}: {v}")
        y -= 0.7*cm

    # insert chart if provided
    if chart_path and chart_path.exists():
        c.drawImage(str(chart_path), 2*cm, 2*cm, width=12*cm, preserveAspectRatio=True, mask='auto')

    c.showPage()
    c.save()
    return out_path
