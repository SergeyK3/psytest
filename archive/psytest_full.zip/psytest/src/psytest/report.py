from docx import Document
from pathlib import Path

def render_report(scores: dict, template_path: Path, out_path: Path) -> Path:
    doc = Document(str(template_path))
    doc.add_heading('Сводная таблица', level=2)
    for k,v in scores.items():
        doc.add_paragraph(f'{k}: {v}')
    doc.save(str(out_path))
    return out_path
