# psytest

Минимальный каркас системы психологического тестирования (PAEI, HEXACO, DISC).

## Быстрый старт
```bash
pip install pandas numpy pydantic streamlit python-docx
python -m psytest.cli_main
streamlit run src/psytest/web_app.py
```
